"""Headless OPX additions: the prompter the engine uses instead of the removed TUI."""
