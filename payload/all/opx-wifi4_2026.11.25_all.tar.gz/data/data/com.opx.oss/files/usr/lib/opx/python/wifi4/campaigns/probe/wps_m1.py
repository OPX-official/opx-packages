from __future__ import annotations

import asyncio
import os
from typing import TYPE_CHECKING, Optional

from wifi4.wlan.station import Association, WlanTransport, build_client_leaving
from wifi4.campaigns.probe.base import BaseApProbe, ProbeResult
from wifi4.dot11 import random_client_mac, str_to_mac
from wifi4.dot11.wsc import messages as M
from wifi4.dot11.wsc.assoc_ie import WPS_REQ_REGISTRAR, wps_assoc_ie
from wifi4.dot11.wsc.identity import apply_wsc_identity
from wifi4.models import IdSource

if TYPE_CHECKING:
    from wifi4.models import AccessPoint
    from wifi4.wlan.interface import WlanInterface

NACK_REPLY_TIMEOUT = 0.5


async def _trigger_m1(
    transport: WlanTransport,
    bssid: bytes,
    our_mac: bytes,
    resend_interval: float = 0.35,
    max_resends: int = 8,
    total_timeout: float = 3.5,
) -> Optional[dict[int, bytes]]:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + total_timeout
    start = M.build_data_frame(bssid, our_mac, bssid, M.eapol_start())
    await transport.send_no_wait(start)
    last = start
    last_send = loop.time()
    resends = 0

    while loop.time() < deadline:
        remaining = deadline - loop.time()
        slice_timeout = min(resend_interval, remaining)
        if slice_timeout <= 0:
            break
        frame = await transport.recv(slice_timeout)
        now = loop.time()
        if frame is None:
            if resends < max_resends:
                await transport.send_no_wait(last)
                last_send = now
                resends += 1
            continue
        parsed = M.parse_rx_frame(frame)
        if parsed is None:
            if now - last_send >= resend_interval and resends < max_resends:
                await transport.send_no_wait(last)
                last_send = now
                resends += 1
            continue
        if parsed.is_identity_request:
            last = M.build_data_frame(bssid, our_mac, bssid, M.eap_identity_response(parsed.eap_id))
            await transport.send_no_wait(last)
            last_send = now
            resends = 0
        elif parsed.wsc_msg_type == M.WPS_M1:
            nonce_e = parsed.attrs.get(M.ATTR_ENROLLEE_NONCE, bytes(16))
            nack = M.build_data_frame(bssid, our_mac, bssid, M.eap_wsc_response(
                parsed.eap_id, M.WSC_NACK, M.build_wsc_nack(nonce_e, os.urandom(16))))
            await transport.send_no_wait(nack)
            nack_deadline = loop.time() + NACK_REPLY_TIMEOUT
            while loop.time() < nack_deadline:
                reply = await transport.recv(nack_deadline - loop.time())
                if reply is None:
                    break
                reply_parsed = M.parse_rx_frame(reply)
                if reply_parsed is None:
                    continue
                if reply_parsed.is_eap_failure:
                    break
                if reply_parsed.wsc_msg_type == M.WPS_M1:
                    await transport.send_no_wait(nack)
            return parsed.attrs
    return None


class WpsM1Probe(BaseApProbe):
    """Probes an AP for WPS M1 identity attributes via Open Association."""
    name = "wps_m1"

    def can_probe(self, ap: AccessPoint) -> bool:
        return bool(ap.wps)

    async def probe(self, iface: WlanInterface, ap: AccessPoint) -> ProbeResult:
        bssid_bytes = str_to_mac(ap.bssid.lower())
        await iface.set_channel(ap.channel)
        await asyncio.sleep(0.1)
        fake_mac = await iface.set_fake_mac(None, bssid_bytes)
        our_mac_str = fake_mac or (iface.mac_address if isinstance(iface.mac_address, str) else None)
        our_mac = str_to_mac(our_mac_str) if our_mac_str else random_client_mac()

        assoc = Association(
            iface, ap.bssid.lower(), ap.ssid or "", ap.channel, our_mac=our_mac,
            assoc_trailer_ies=wps_assoc_ie(WPS_REQ_REGISTRAR, ap.wps_version == "2.0"),
            auth_timeout=0.6,
            assoc_timeout=0.8,
            beacon_frame=ap.last_beacon_frame,
        )
        transport = WlanTransport(iface, bssid_bytes, our_mac)
        assoc.start()
        try:
            if not await assoc.associate(attempts=2):
                return ProbeResult(False, detail=assoc.fail_reason or "no association response")
            transport.start()
            attrs = await _trigger_m1(transport, bssid_bytes, our_mac)
        finally:
            transport.stop()
            assoc.stop()
            try:
                await iface.send_no_wait(build_client_leaving(bssid_bytes, our_mac))
            except Exception:
                pass
            await iface.clear_fake_mac()

        if not attrs or not apply_wsc_identity(ap.identity, IdSource.WSC_M1, attrs):
            return ProbeResult(False, detail="no WPS M1 response")

        return ProbeResult(
            True,
            source=IdSource.WSC_M1.label,
            vendor=ap.identity.manufacturer,
            model=ap.identity.model,
        )
