"""802.11 information-element builders + the shared RSN helper (pure spec).

Consolidates the SSID / rates / RSN / DS-param IE assembly that the auth, assoc, and
probe frame builders each used to hand-roll, plus the client-side RSN rewrite the PMKID
attack uses.
"""
from __future__ import annotations

from collections.abc import Iterator
from typing import Optional

from wifi4.dot11.rsn import AKM_PSK, CIPHER_AES_128_CMAC, RSN_OUI


def iter_information_elements(data: bytes, start: int = 0) -> Iterator[tuple[int, bytes, bytes]]:
    """Walk 802.11 Information Elements (1B tag, 1B len), yielding (tag_id, body, raw)."""
    i, n = start, len(data)
    while i + 2 <= n:
        tag_id = data[i]
        length = data[i + 1]
        end = i + 2 + length
        if end > n:
            break
        yield tag_id, data[i + 2 : end], data[i : end]
        i = end

# Supported / Extended supported rate menus (APs only spot-check that they parse).
SUPPORTED_RATES = bytes([0x82, 0x84, 0x8B, 0x96, 0x0C, 0x12, 0x18, 0x24])
EXT_SUPPORTED_RATES = bytes([0x30, 0x48, 0x60, 0x6C])
SUPPORTED_RATES_5GHZ = bytes([0x8C, 0x12, 0x98, 0x24, 0xB0, 0x48, 0x60, 0x6C])

# Generic WPA2-PSK-CCMP RSN IE (tag 48): version 1, CCMP group + pairwise, single
# AKM = PSK, no PMF. The client-side fallback when the AP's own IE is unusable.
GENERIC_RSN_IE = bytes.fromhex("30140100000fac040100000fac040100000fac020000")

_RSN_CAP_MFPC = 0x0080          # RSN caps MFPC bit (bit 7)
_BIP_CMAC_128 = RSN_OUI + bytes([CIPHER_AES_128_CMAC])


SSID_MAX_OCTETS = 32


def ssid_ie(ssid: str) -> bytes:
    """SSID IE (tag 0): UTF-8, truncated to the 32-byte spec maximum."""
    s = ssid.encode("utf-8", "ignore")[:SSID_MAX_OCTETS]
    return bytes([0x00, len(s)]) + s


def rates_ie(channel: int = 1) -> bytes:
    """Supported Rates IE (tag 1), band-aware (OFDM on 5 GHz, CCK+OFDM on 2.4 GHz)."""
    rates = SUPPORTED_RATES_5GHZ if channel > 14 else SUPPORTED_RATES
    return bytes([0x01, len(rates)]) + rates


def ext_rates_ie(channel: int = 1) -> bytes:
    """Extended Supported Rates IE (tag 50), omitted on 5 GHz where all rates fit tag 1."""
    if channel > 14:
        return b""
    return bytes([0x32, len(EXT_SUPPORTED_RATES)]) + EXT_SUPPORTED_RATES


def ht_cap_ie() -> bytes:
    """HT Capabilities IE (tag 45): 20 MHz-only, 1-stream MCS 0-7, static SMPS."""
    return bytes([0x2D, 0x1A]) + b"\x2d\x01\x1b" + b"\xff" + (b"\x00" * 15) + (b"\x00" * 7)


def ds_param_ie(channel: int) -> bytes:
    """DS Parameter Set IE (tag 3): the operating channel."""
    return bytes([0x03, 0x01, channel & 0xFF])


def csa_ie(new_channel: int, *, mode: int = 1, count: int = 0) -> bytes:
    """Channel Switch Announcement IE (tag 37): mode (1 = halt TX until the switch), target channel, count."""
    return bytes([0x25, 0x03, mode & 0xFF, new_channel & 0xFF, count & 0xFF])


def ecsa_ie(new_channel: int, *, operating_class: int, mode: int = 1, count: int = 0) -> bytes:
    """Extended Channel Switch Announcement IE (tag 60): mode, new operating class, target channel, count."""
    return bytes([0x3C, 0x04, mode & 0xFF, operating_class & 0xFF, new_channel & 0xFF, count & 0xFF])


def secondary_channel_offset_ie(offset: int = 0) -> bytes:
    """Secondary Channel Offset IE (tag 62): 0 = SCN (20 MHz), 1 = above, 3 = below."""
    return bytes([0x3E, 0x01, offset & 0xFF])


def force_psk_akm(rsn_ie: bytes, akm: int = AKM_PSK, *, pmf_capable: bool = False) -> Optional[bytes]:
    """Rewrite an RSN IE to a single ``00-0F-AC:akm`` AKM (PSK by default) over the
    AP's ciphers, authoring a client RSN tail that mirrors the AP's PMF posture:
    ``pmf_capable`` → MFPC=1 (MFPR=0) + BIP group-mgmt (a transition AP often only
    associates PMF-capable STAs); else clean 0x0000 caps. Drops the AP's PMKID list
    either way; returns None if the IE is malformed (caller falls back to generic).

    Selecting one PSK AKM (not echoing the AP's full list, which claims SAE and gets
    us ignored) runs the PSK 4-way → PMKID in M1. RSNE body layout: version(2)
    group(4) pw_count(2) pw(4*n) akm_count(2) akm(4*m) [caps(2)] [pmkid_count(2)
    pmkid...] [group-mgmt(4)]."""
    if len(rsn_ie) < 2 or rsn_ie[0] != 0x30:
        return None
    body = rsn_ie[2:2 + rsn_ie[1]]
    if len(body) < 8:
        return None
    pw_count = int.from_bytes(body[6:8], "little")
    akm_off = 8 + 4 * pw_count
    if akm_off + 2 > len(body):
        return None
    akm_count = int.from_bytes(body[akm_off:akm_off + 2], "little")
    akm_end = akm_off + 2 + 4 * akm_count
    if akm_end > len(body):
        return None
    new_akm = b"\x01\x00" + RSN_OUI + bytes([akm])        # count=1 + 00-0F-AC:akm
    if pmf_capable:                                       # MFPC=1, PMKID-count 0, BIP
        tail = _RSN_CAP_MFPC.to_bytes(2, "little") + b"\x00\x00" + _BIP_CMAC_128
    else:
        tail = b"\x00\x00"                               # clean caps, no MFP
    new_body = body[:akm_off] + new_akm + tail
    return bytes([0x30, len(new_body)]) + new_body
