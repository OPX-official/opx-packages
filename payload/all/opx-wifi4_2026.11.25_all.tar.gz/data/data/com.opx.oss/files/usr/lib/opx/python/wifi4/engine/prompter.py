"""A prompter with no user interface.

The bring-up engine was written against a Textual prompter (progress modal, replug dialog,
error screen). OPX OSS drives the same engine from the app, so every interaction that used to
open a modal becomes a no-op here and the outcome is reported over the engine's JSON stream
instead. Nothing raises, so a missing UI can never break a bring-up.
"""
from __future__ import annotations

import logging
from collections.abc import Callable

logger = logging.getLogger(__name__)


class HeadlessPrompter:
    def __init__(self, app=None) -> None:
        self._app = app
        self.last_error: tuple[str, str] | None = None

    async def open(self, title: str) -> None:
        logger.debug("bring-up: %s", title)

    def close(self) -> None:
        pass

    def status(self, message: str) -> None:
        logger.debug("bring-up status: %s", message)

    def status_progress(self, fraction: float, message: str) -> None:
        logger.debug("bring-up %.0f%%: %s", fraction * 100, message)

    def error(self, title: str, body: str) -> None:
        self.last_error = (title, body)
        logger.warning("%s: %s", title, body)

    async def run_with_terminal(self, run: Callable[[], int]) -> int | None:
        # No terminal exists in this app; privileged steps are not part of the Android path.
        return None

    async def ask(self, dialog):
        # Modal dialogs have no equivalent here: treat the answer as "dismissed".
        return None

    async def wait_replug(self, device_id):
        return None

    def begin_assistant(self, greeting, messages, *, intro_delay: float = 2.0) -> None:
        pass

    async def end_assistant(self, ok: bool) -> None:
        pass
