"""The WEP footer without the removed Textual focus model.

``WepCampaign.status_under_dash`` was the only shipped backend caller of the TUI's
``wep_status_lines``. The numbers come from wifi4's own WEP capture store, so the app can show
the usable-IV progress while the campaign is replaying.
"""
from __future__ import annotations

from wifi4.crack.wep import CRACK_READY_THRESHOLD


def wep_status_lines(ap, array, campaign, now: float) -> list[str]:
    samples = array.wep_store.crack_sample_count(ap.bssid) if array else 0
    usable = f"{samples:,}" if samples else "0"
    if samples < CRACK_READY_THRESHOLD:
        usable = f"{usable}/{CRACK_READY_THRESHOLD // 1000}k"
    lines = []
    if campaign is not None:
        state = getattr(getattr(campaign, "replay", None), "state", "")
        lines.append(f"Fake-Auth: {state or 'starting'}")
    lines.append(f"Usable IVs: {usable}")
    return lines
